namespace DAL.DTOs
{
    public class ComboIdTextoDto
    {
        public string Id { get; set; }
        public string Descricao { get; set; }
    }

    public class ComboIdIntDto
    {
        public int Id { get; set; }
        public string Descricao { get; set; }
    }
}
