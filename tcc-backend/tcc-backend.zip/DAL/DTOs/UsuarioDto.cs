﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DAL.DTOs
{
    public class UsuarioDto
    {
        public string Nome { get; set; }

        public string Login { get; set; }
    }
}
