using System;
namespace DAL.DTOs
{
     public class UsuarioGridDto
     {
          public string Nome { get; set; }

          public string Cpf { get; set; }

          public string Rg { get; set; }

          public string DataNascimento { get; set; }

          public string Email { get; set; }

     }
}
